package socialapp;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

/**
 * Bei dieser Klasse handelt sich um die Implementation aller Services welche eine Rest-Anfrage bearbeitet 
 * und die Antwort zurueschickt. Hier werden die Listen aller Anfragen bereitgestellt ohne Geodaten.
 *
 * @author Konstantinos Tsiamis
 * @version M�rz 2017
 */
@ManagedBean(name="offersService", eager=true)//Ignorieren dient nur zum Testen der Webapplikation hat nichts mit der Suche zu tun
@SessionScoped//Ignorieren dient nur zum Testen der Webapplikation hat nichts mit der Suche zu tun
public class OffersService implements Serializable {

	private static final long serialVersionUID = -9150122909138342684L;//Ignorieren dient nur zum Testen der Webapplikation hat nichts mit der Suche zu tun
	/**
	 * In dieser Funktion wird eine Liste aller Traeger zurueckgegeben
	 * 
	 * @return Liste aller Traeger
	 */
    public List<Traeger> getAllTraegers() 
	 { 
    	 //Initialisiere die Verbindung zum MySql Server und deren Datenbank
		   Connection conn = null;
	       List<Traeger> traegers = new ArrayList<Traeger>();
	       PreparedStatement pstm = null;
	       ResultSet rs = null; 

	       try
	       {
	           String url = "jdbc:mysql://localhost:3306/sozialraum_db_neu"; //Setze die Url zur Datenbank
	           Class.forName ("com.mysql.jdbc.Driver");//Setze den Treiber
	           conn = DriverManager.getConnection (url,"root","30958fgRGH");//Starte die Verbindung
	           pstm = conn.prepareStatement("SELECT * from traeger t ");//Uebergebe die Sql-Anweisung 
	           rs =pstm.executeQuery();//Fuehre die Sql-Anweisung aus
	           while(rs.next())//Filter die Information und setze in unserem Objekt Traeger
	           {
	        	   Traeger t = new Traeger();
	        	   t.setId(rs.getInt(1));
	        	   t.setName(rs.getString(2));
	        	   t.setPlz(rs.getInt(3));
	        	   t.setStrasse(rs.getString(4));
	        	   t.setHausnummer(rs.getInt(5));
	        	   t.setTelefon(rs.getString(6));
	        	   t.setFax(rs.getString(7));
	        	   t.setAnsprechpartner(rs.getString(8));
	        	   t.setEmail(rs.getString(9));
	        	   t.setWebsite(rs.getString(10));
	        	   t.setAngebot(rs.getString(11));
	        	   t.setSprachen(rs.getString(12));
	        	   traegers.add(t);
	           }
   
	       }
	       catch (Exception n)
	       {
	           n.printStackTrace();

	       }
	       finally
	       {
	           if (conn != null)
	           {
	               try
	               {
	                   conn.close ();//Schlie�e die Verbindung zur Datenbank
	                   //System.out.println ("Database connection terminated");
	               }
	               catch (Exception n) { /* ignore close errors */ }
	           }
	       }
		return traegers;//Gebe die Liste aus
	   }   
	 /**
	  * Diese Methode implementiert den Service OffersService und gibt die Liste f�r die Oberkategorien aus
	  * 
	  * @return Liste der Oberkategorie
	  */
	 public List<Kategorie> getAllKategories()
	 {
		 //Initialisiere die Verbindung zum MySql Server und deren Datenbank
		   Connection conn = null;
	       List<Kategorie> kategories = new ArrayList<Kategorie>();
	       PreparedStatement pstm = null;
	       ResultSet rs = null;
	       
	       try
	       {
	           String url = "jdbc:mysql://localhost:3306/sozialraum_db_neu"; //Setze die Url zur Datenbank
	           Class.forName ("com.mysql.jdbc.Driver"); //Setze den Treiber
	           conn = DriverManager.getConnection (url,"root","30958fgRGH");//Starte die Verbindung
	           pstm = conn.prepareStatement( "SELECT distinct sozialraum_db_neu.kategorie.id, "
	           		+ "sozialraum_db_neu.kategorie.name, "
	           		+ "sozialraum_db_neu.kat_mapping.parent_kat_id"
	           		+ " FROM sozialraum_db_neu.kategorie"
	           		+ " INNER JOIN kat_mapping"
	           		+ " ON kat_mapping.parent_kat_id = 0"
	           		+ " AND kategorie.id = kat_mapping.kat_id");//Uebergebe die Sql-Anweisung
	           rs =pstm.executeQuery();//Fuehre die Sql-Anweisung aus
	           while(rs.next())//Filter die Information und setze in unserem Objekt Kategorie
	           {
	        	   Kategorie k = new Kategorie();
	        	   k.setId(rs.getInt(1));
	        	   k.setName(rs.getString(2));
	        	
	        	   kategories.add(k);
	           }
  
	       }
	       catch (Exception n)
	       {
	           n.printStackTrace();

	       }
	       finally
	       {
	           if (conn != null)
	           {
	               try
	               {
	                   conn.close ();//Schlie�e die Verbindung zur Datenbank
	                   //System.out.println ("Database connection terminated");
	               }
	               catch (Exception n) { /* ignore close errors */ }
	           }
	       }
		return kategories;//Gebe die Liste aus
	   }  
	 /**
	  * Diese Methode implementiert den Service SubofferWebService und gibt alle
	  * Unterkatorien, die existieren, aus
	  * 
	  * @return Liste aller Unterkategorien
	  */
	 public List<Unterkategorien> getAllUKategories()
	  {
		//Initialisiere die Verbindung zum MySql Server und deren Datenbank
		  Connection conn = null;
	      List<Unterkategorien> ukategories = new ArrayList<Unterkategorien>();
	      PreparedStatement pstm = null;
	      ResultSet rs = null;
	      
	      try
	      {
	          String url = "jdbc:mysql://localhost:3306/sozialraum_db_neu";//Setze die Url zur Datenbank
	          Class.forName ("com.mysql.jdbc.Driver");//Setze den Treiber
	          conn = DriverManager.getConnection (url,"root","30958fgRGH");//Starte die Verbindung
	          pstm = conn.prepareStatement("SELECT distinct sozialraum_db_neu.kategorie.id, "
	          		+ "sozialraum_db_neu.kategorie.name, "
	          		+ "sozialraum_db_neu.kat_mapping.parent_kat_id "
	          		+ "FROM sozialraum_db_neu.kategorie "
	          		+ "INNER JOIN kat_mapping "
	          		+ "ON kat_mapping.parent_kat_id  "
	          		+ "AND kategorie.id = kat_mapping.kat_id ");//Uebergebe die Sql-Anweisung
	          rs =pstm.executeQuery();//Fuehre die Sql-Anweisung aus
	          while(rs.next())//Filter die Information und setze in unserem Objekt Unterkategorie
	          {
	       	   Unterkategorien uk = new Unterkategorien();
	       	   uk.setId(rs.getInt(1));
	       	   uk.setName(rs.getString(2));
	       	   uk.setParentId(rs.getInt(3));
	       	
	       	   ukategories.add(uk);
	          }

	      }
	      catch (Exception n)
	      {
	          n.printStackTrace();

	      }
	      finally
	      {
	          if (conn != null)
	          {
	              try
	              {
	                  conn.close ();//Schlie�e die Verbindung zur Datenbank
	                  //System.out.println ("Database connection terminated");
	              }
	              catch (Exception n) { /* ignore close errors */ }
	          }
	      }
		return ukategories;//Gebe die Liste aus
	  }  	 
  /**
   * Diese Methode implementiert den Service SubOffersWebService2 bei eine Liste zur gehoerigen Oberkategorie
   * zurueckgegeben wird. 
   *  
   * @param catid Die ID der Oberkategorie
   * @return Liste der Unterkategorie die zur ID der Oberkategorie gehoert
   */
  public List<Unterkategorien> getselectedUKategories(int catid)
  {
	//Initialisiere die Verbindung zum MySql Server und deren Datenbank
	  Connection conn = null;
      List<Unterkategorien> ukategories = new ArrayList<Unterkategorien>();
      PreparedStatement pstm = null;
      ResultSet rs = null;
      
      try
      {
          String url = "jdbc:mysql://localhost:3306/sozialraum_db_neu";//Setze die Url zur Datenbank
          Class.forName ("com.mysql.jdbc.Driver");//Setze den Treiber
          conn = DriverManager.getConnection (url,"root","30958fgRGH");//Starte die Verbindung
          pstm = conn.prepareStatement("SELECT distinct sozialraum_db_neu.kategorie.id, "
          		+ "sozialraum_db_neu.kategorie.name, "
          		+ "sozialraum_db_neu.kat_mapping.parent_kat_id "
          		+ "FROM sozialraum_db_neu.kategorie "
          		+ "INNER JOIN kat_mapping "
          		+ "ON kat_mapping.parent_kat_id = ? "
          		+ "AND kategorie.id = kat_mapping.kat_id ");//Uebergebe die Sql-Anweisung
          pstm.setInt(1, catid);//Setze f�r den Platzhalter ? den Wert
          rs =pstm.executeQuery();//Fuehre die Sql-Anweisung aus
          while(rs.next())//Filter die Information und setze in unserem Objekt Unterkategorie
          {
       	   Unterkategorien uk = new Unterkategorien();
       	   uk.setId(rs.getInt(1));
       	   uk.setName(rs.getString(2));
       	   uk.setParentId(rs.getInt(3));
       	
       	   ukategories.add(uk);
          }

      }
      catch (Exception n)
      {
          n.printStackTrace();

      }
      finally
      {
          if (conn != null)
          {
              try
              {
                  conn.close ();//Schlie�e die Verbindung zur Datenbank
                  //System.out.println ("Database connection terminated");
              }
              catch (Exception n) { /* ignore close errors */ }
          }
      }
	return ukategories;//Gebe die Liste aus
  }  
  
  /**
   * Diese Methode implementiert den Service Trkatmapping  bei dser eine Liste der ID der Traeger zuur ID der Kategorie
   * zurueckgegeben wird. 
   *  
   * @return Liste der TraegerKategoriemapping
   */
  public List<Trkatmapping> getAllTrk()
  {
	//Initialisiere die Verbindung zum MySql Server und deren Datenbank
	  Connection conn = null;
      List<Trkatmapping> trkategories = new ArrayList<Trkatmapping>();
      PreparedStatement pstm = null;
      ResultSet rs = null;
      
      try
      {
          String url = "jdbc:mysql://localhost:3306/sozialraum_db_neu";//Setze die Url zur Datenbank
          Class.forName ("com.mysql.jdbc.Driver");//Setze den Treiber
          conn = DriverManager.getConnection (url,"root","30958fgRGH");//Starte die Verbindung
          pstm = conn.prepareStatement("SELECT * from traeger_kat_mapping trk "); //Uebergebe die Sql-Anweisung    
          rs =pstm.executeQuery();//Fuehre die Sql-Anweisung aus
          while(rs.next())//Filter die Information und setze in unserem Objekt Trkatmapping
          {
           Trkatmapping trk = new Trkatmapping();
       	   trk.setTraegerId(rs.getInt(1));
       	   trk.setKatId(rs.getInt(2));
       	
       	   trkategories.add(trk);
          }

      }
      catch (Exception n)
      {
          n.printStackTrace();

      }
      finally
      {
          if (conn != null)
          {
              try
              {
                  conn.close ();//Schlie�e die Verbindung zur Datenbank
                  //System.out.println ("Database connection terminated");
              }
              catch (Exception n) { /* ignore close errors */ }
          }
      }
	return trkategories;//Gebe die Liste aus
  } 
   
  /**
   * In dieser Funktion wird eine Liste aller Traeger zurueckgegeben
   * entsprechend der Suchparametern. Hier werden 6 Faelle behandelt, 
   * um alle Suchkriterien durchzufuehren. Man muss immer drei Parameter uebergeben 
   * um diese Funktion aufzurufen dabei steht null f�r kein suchwort, 
   * catid = 0 und subid = 0 f�r keine oberkategorie
   * und keine unterkategorie
   * 
   * @param keyword Der Suchbegriff der uebergeben wurde
   * @param catid Die ID der Oberkategorie
   * @param subid Die ID der Unterkategorie
   * @return Die Liste der Traeger entsprechend der Suchparameter
   */
  public List<Traeger> getAllResults(String keyword, int catid, int subid) 
  {
	//Initialisiere die Verbindung zum MySql Server und deren Datenbank
	  Connection conn = null;
      List<Traeger> traegers = new ArrayList<Traeger>();
      PreparedStatement pstm = null;
      ResultSet rs = null; 
      
      System.out.println("keyword:" + keyword);//Test der Uebergabe
      System.out.println("catid:" + catid);//Test der Uebergabe
      System.out.println("subid:" + subid);//Test der Uebergabe
      if((keyword.equals("null")) && (catid != 0) && (subid == 0)) //Fall1:Nur Oberkategorie
      {
    	  System.out.println("fall1");
    	  try
          {
             String url = "jdbc:mysql://localhost:3306/sozialraum_db_neu";//Setze die Url zur Datenbank
             Class.forName ("com.mysql.jdbc.Driver");//Setze den Treiber
             conn = DriverManager.getConnection (url,"root","30958fgRGH");//Starte die Verbindung
             pstm = conn.prepareStatement("SELECT  * FROM sozialraum_db_neu.kategorie k, "
             		+ "sozialraum_db_neu.traeger_kat_mapping tkm, "
             		+ "sozialraum_db_neu.traeger t,"
             		+ "sozialraum_db_neu.kat_mapping km "
             		+ "WHERE t.id = tkm.traeger_id "
             		+ "AND k.id = tkm.traeger_kat_id "
             		+ "AND tkm.traeger_id = t.id "
             		+ "AND k.id = ? "
             		+ "AND k.id = km.kat_id "
             		+ "AND km.parent_kat_id = 0 ");//Uebergebe die Sql-Anweisung 
             pstm.setInt(1, catid);//Setze f�r den Platzhalter ? den Wert
             rs =pstm.executeQuery();//Fuehre die Sql-Anweisung aus
             while(rs.next())//Filter die Information und setze in unserem Objekt Traeger
             {
                Traeger t = new Traeger();
        	    t.setId(rs.getInt(5));
        	    t.setName(rs.getString(6));
        	    t.setPlz(rs.getInt(7));
        	    t.setStrasse(rs.getString(8));
        	    t.setHausnummer(rs.getInt(9));
        	    t.setTelefon(rs.getString(10));
        	    t.setFax(rs.getString(11));
        	    t.setAnsprechpartner(rs.getString(12));
        	    t.setEmail(rs.getString(13));
        	    t.setWebsite(rs.getString(14));
                t.setAngebot(rs.getString(15));
                t.setSprachen(rs.getString(16));
        	    traegers.add(t);
              }
            }
            catch (Exception n)
            {
              n.printStackTrace();

            }
            finally
            {
              if (conn != null)
              {
                try
                {
                   conn.close ();//Schlie�e die Verbindung zur Datenbank
                   //System.out.println ("Database connection terminated");
                }
                catch (Exception n) { /* ignore close errors */ }
               }
            }
         }
   
      else if((keyword.equals("null")) &&(catid != 0) && (subid != 0))//Fall2:Nur Oberkategorie und Unterkategorie
      {
    	  System.out.println("fall2");
    	  try
          {
             String url = "jdbc:mysql://localhost:3306/sozialraum_db_neu";//Setze die Url zur Datenbank
             Class.forName ("com.mysql.jdbc.Driver");//Setze den Treiber
             conn = DriverManager.getConnection (url,"root","30958fgRGH");//Starte die Verbindung
             pstm = conn.prepareStatement("SELECT DISTINCT * FROM sozialraum_db_neu.kategorie k, "
             		+ "sozialraum_db_neu.traeger_kat_mapping tkm, "
             		+ "sozialraum_db_neu.traeger t "
             		+ "WHERE k.id = tkm.traeger_kat_id "
             		+ "AND t.id = tkm.traeger_id "
             		+ "AND k.id = ? " );//Uebergebe die Sql-Anweisung
            // pstm.setInt(1, catid);
             pstm.setInt(1, subid);	//Setze f�r den Platzhalter ? den Wert
      	     rs =pstm.executeQuery();//Fuehre die Sql-Anweisung aus
             while(rs.next())//Filter die Information und setze in unserem Objekt Traeger
             {
                Traeger t = new Traeger();
        	    t.setId(rs.getInt(5));
        	    t.setName(rs.getString(6));
        	    t.setPlz(rs.getInt(7));
        	    t.setStrasse(rs.getString(8));
        	    t.setHausnummer(rs.getInt(9));
        	    t.setTelefon(rs.getString(10));
        	    t.setFax(rs.getString(11));
        	    t.setAnsprechpartner(rs.getString(12));
        	    t.setEmail(rs.getString(13));
        	    t.setWebsite(rs.getString(14));
                t.setAngebot(rs.getString(15));
                t.setSprachen(rs.getString(16));
        	    traegers.add(t);
              }
            }
            catch (Exception n)
            {
              n.printStackTrace();

            }
            finally
            {
              if (conn != null)
              {
                try
                {
                   conn.close ();//Schlie�e die Verbindung zur Datenbank
                   //System.out.println ("Database connection terminated");
                }
                catch (Exception n) { /* ignore close errors */ }
               }
            }  
      }
      else if ((!keyword.equals("null")) && (catid != 0) && (subid !=0))//Fall3: Suchwort  mit Ober- und Unterkategorie
      {
    	  System.out.println("fall3");
     	 try
          {
             String url = "jdbc:mysql://localhost:3306/sozialraum_db_neu";//Setze die Url zur Datenbank
             Class.forName ("com.mysql.jdbc.Driver");//Setze den Treiber
             conn = DriverManager.getConnection (url,"root","30958fgRGH");//Starte die Verbindung
             pstm = conn.prepareStatement("SELECT * FROM sozialraum_db_neu.kategorie k, "
             		+ "sozialraum_db_neu.traeger_kat_mapping tkm,  "
             		+ "sozialraum_db_neu.traeger t "
             		+ "WHERE k.id = tkm.traeger_kat_id "
             		+ "AND t.id =tkm.traeger_id "
             		+ "AND k.id = ? "
             		+ "AND( t.plz LIKE ? "
             		+ "OR t.strasse LIKE ? "
             		+ "OR t.name LIKE ? "
             		+ "OR t.hausnummer LIKE ? "
             		+ "OR t.telefon LIKE ? "
             		+ "OR t.fax LIKE ? "
             		+ "OR t.ansprechpartner LIKE ? "
             		+ "OR t.email LIKE ? "
             		+ "OR t.website LIKE ? "
             		+ "OR t.angebot LIKE ? "
             		+ "OR t.sprachen LIKE ?)");//Uebergebe die Sql-Anweisung
             
             keyword = "%" + keyword+ "%";//Schluesselwort fuer den Platzhalter
            // pstm.setInt(1, catid);
             pstm.setInt(1, subid);//Setze f�r den Platzhalter ? den Wert
             pstm.setString(2, keyword);
             pstm.setString(3, keyword);	
             pstm.setString(4, keyword);
             pstm.setString(5, keyword);	
             pstm.setString(6, keyword);
             pstm.setString(7, keyword);	
             pstm.setString(8, keyword);
             pstm.setString(9, keyword);
             pstm.setString(10, keyword);
             pstm.setString(11, keyword);
             pstm.setString(12, keyword);
      	     rs =pstm.executeQuery();
             while(rs.next())//Filter die Information und setze in unserem Objekt Traeger
             {
                Traeger t = new Traeger();
        	    t.setId(rs.getInt(5));
        	    t.setName(rs.getString(6));
        	    t.setPlz(rs.getInt(7));
        	    t.setStrasse(rs.getString(8));
        	    t.setHausnummer(rs.getInt(9));
        	    t.setTelefon(rs.getString(10));
        	    t.setFax(rs.getString(11));
        	    t.setAnsprechpartner(rs.getString(12));
        	    t.setEmail(rs.getString(13));
        	    t.setWebsite(rs.getString(14));
                t.setAngebot(rs.getString(15));
                t.setSprachen(rs.getString(16));
        	    traegers.add(t);
              }
            }
            catch (Exception n)
            {
              n.printStackTrace();

            }
            finally
            {
              if (conn != null)
              {
                try
                {
                   conn.close ();//Schlie�e die Verbindung zur Datenbank
                   //System.out.println ("Database connection terminated");
                }
                catch (Exception n) { /* ignore close errors */ }
               }
            }  
      }
      else if((!keyword.equals("null")) && (catid != 0) && (subid == 0)) //Fall4 Suchwort  mit Oberkategorie
      {
    	  System.out.println("fall4");
     	 try
          {
             String url = "jdbc:mysql://localhost:3306/sozialraum_db_neu";//Setze die Url zur Datenbank
             Class.forName ("com.mysql.jdbc.Driver");//Setze den Treiber
             conn = DriverManager.getConnection (url,"root","30958fgRGH");//Starte die Verbindung
             pstm = conn.prepareStatement("SELECT DISTINCT * FROM sozialraum_db_neu.kategorie k, "
             		+ "sozialraum_db_neu.traeger_kat_mapping tkm,"
             		+ "sozialraum_db_neu.traeger t "
             		+ "WHERE k.id = ? "
             		+ "AND tkm.traeger_kat_id = k.id "
             		+ "AND t.id = tkm.traeger_id "
             		+ "AND ( t.plz LIKE ? "
             		+ "OR t.strasse LIKE ? "
             		+ "OR t.name LIKE ? "
             		+ "OR t.hausnummer LIKE ? "
             		+ "OR t.telefon LIKE ? "
             		+ "OR t.fax LIKE ? "
             		+ "OR t.ansprechpartner LIKE ? "
             		+ "OR t.email LIKE ? "
             		+ "OR t.website LIKE ? "
             		+ "OR t.angebot LIKE ? "
             		+ "OR t.sprachen LIKE ?)");//Uebergebe die Sql-Anweisung
             keyword = "%" + keyword+ "%";//Schluesselwort fuer den Platzhalter
             pstm.setInt(1, catid);	//Setze f�r den Platzhalter ? den Wert
             pstm.setString(2, keyword);
             pstm.setString(3, keyword);	
             pstm.setString(4, keyword);
             pstm.setString(5, keyword);	
             pstm.setString(6, keyword);
             pstm.setString(7, keyword);	
             pstm.setString(8, keyword);
             pstm.setString(9, keyword);
             pstm.setString(10, keyword);
             pstm.setString(11, keyword);
             pstm.setString(12, keyword);
      	     rs =pstm.executeQuery();//Fuehre die Sql-Anweisung aus
             while(rs.next())//Filter die Information und setze in unserem Objekt Traeger
             {
                Traeger t = new Traeger();
        	    t.setId(rs.getInt(5));
        	    t.setName(rs.getString(6));
        	    t.setPlz(rs.getInt(7));
        	    t.setStrasse(rs.getString(8));
        	    t.setHausnummer(rs.getInt(9));
        	    t.setTelefon(rs.getString(10));
        	    t.setFax(rs.getString(11));
        	    t.setAnsprechpartner(rs.getString(12));
        	    t.setEmail(rs.getString(13));
        	    t.setWebsite(rs.getString(14));
                t.setAngebot(rs.getString(15));
                t.setSprachen(rs.getString(16));
        	    traegers.add(t);
              }
            }
            catch (Exception n)
            {
              n.printStackTrace();

            }
            finally
            {
              if (conn != null)
              {
                try
                {
                   conn.close ();//Schlie�e die Verbindung zur Datenbank
                   //System.out.println ("Database connection terminated");
                }
                catch (Exception n) { /* ignore close errors */ }
               }
            }  
      }
      else if((!keyword.equals("null")) && (catid == 0) && (subid == 0))//Fall5 nur Suchwort
      {
    	  System.out.println("fall5");
     	 try
          {
             String url = "jdbc:mysql://localhost:3306/sozialraum_db_neu";//Setze die Url zur Datenbank
             Class.forName ("com.mysql.jdbc.Driver");//Setze den Treiber
             conn = DriverManager.getConnection (url,"root","30958fgRGH");//Starte die Verbindung
             pstm = conn.prepareStatement("SELECT DISTINCT * FROM"
             		+ " sozialraum_db_neu.traeger t "
             		+ "WHERE ( t.plz LIKE ? "
             		+ "OR t.strasse LIKE ? "
             		+ "OR t.name LIKE ? "
             		+ "OR t.hausnummer LIKE ? "
             		+ "OR t.telefon LIKE ? "
             		+ "OR t.fax LIKE ? "
             		+ "OR t.ansprechpartner LIKE ? "
             		+ "OR t.email LIKE ? "
             		+ "OR t.website LIKE ? "
             		+ "OR t.angebot LIKE ? "
             		+ "OR t.sprachen LIKE ?)");//Uebergebe die Sql-Anweisung
             keyword = "%" + keyword+ "%";//Schluesselwort fuer den Platzhalter
             pstm.setString(1, keyword);//Setze f�r den Platzhalter ? den Wert
             pstm.setString(2, keyword);	
             pstm.setString(3, keyword);
             pstm.setString(4, keyword);	
             pstm.setString(5, keyword);
             pstm.setString(6, keyword);	
             pstm.setString(7, keyword);
             pstm.setString(8, keyword);
             pstm.setString(9, keyword);
             pstm.setString(10, keyword);
             pstm.setString(11, keyword);
      	     rs =pstm.executeQuery();//Fuehre die Sql-Anweisung aus
             while(rs.next())//Filter die Information und setze in unserem Objekt Traeger
             {
                Traeger t = new Traeger();
        	       t.setId(rs.getInt(1));
        	       t.setName(rs.getString(2));
        	       t.setPlz(rs.getInt(3));
        	       t.setStrasse(rs.getString(4));
        	       t.setHausnummer(rs.getInt(5));
        	       t.setTelefon(rs.getString(6));
        	       t.setFax(rs.getString(7));
        	       t.setAnsprechpartner(rs.getString(8));
        	       t.setEmail(rs.getString(9));
        	       t.setWebsite(rs.getString(10));
        	       t.setAngebot(rs.getString(11));
        	       t.setSprachen(rs.getString(12));
        	       traegers.add(t);
              }
            }
            catch (Exception n)
            {
              n.printStackTrace();

            }
            finally
            {
              if (conn != null)
              {
                try
                {
                   conn.close ();//Schlie�e die Verbindung zur Datenbank
                   //System.out.println ("Database connection terminated");
                }
                catch (Exception n) { /* ignore close errors */ }
               }
            }  
      }
     else
     {
    	traegers = getAllTraegers();  
     }
      
	return traegers;//Gebe die Liste aus
  }
}