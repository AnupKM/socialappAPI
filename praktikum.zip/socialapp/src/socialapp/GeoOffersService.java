package socialapp;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;


public class GeoOffersService 
{
	Connection conn = null;
    ArrayList<String> arr = new ArrayList<String>();
    PreparedStatement pstm = null;
    ResultSet rs = null;
    int i;
    
    public List<Traeger> getAllTraegers(int la, int lo) 
	 { 
		 
		   Connection conn = null;
	       List<Traeger> traegers = new ArrayList<Traeger>();
	       PreparedStatement pstm = null;
	       ResultSet rs = null; 

	       try
	       {
	           String url = "jdbc:mysql://localhost:3306/sozialraum_db_neu";
	           Class.forName ("com.mysql.jdbc.Driver");
	           conn = DriverManager.getConnection (url,"root","1234");
	           pstm = conn.prepareStatement("SELECT * from traeger t ");
	           rs =pstm.executeQuery();
	           while(rs.next())
	           {
	        	   Traeger t = new Traeger();
	        	   t.setId(rs.getInt(1));
	        	   t.setName(rs.getString(2));
	        	   t.setPlz(rs.getInt(3));
	        	   t.setStrasse(rs.getString(4));
	        	   t.setHausnummer(rs.getInt(5));
	        	   t.setTelefon(rs.getString(6));
	        	   t.setFax(rs.getString(7));
	        	   t.setAnsprechpartner(rs.getString(8));
	        	   t.setEmail(rs.getString(9));
	        	   t.setWebsite(rs.getString(10));
	        	   t.setAngebot(rs.getString(11));
	        	   t.setSprachen(rs.getString(12));
	        	   t.setX(rs.getInt(13));
          	       t.setY(rs.getInt(14));
          	       int distance = (int) (Math.sqrt(((t.getX()-(la))*(t.getX()-(la)))*69.1 *69.1)+((t.getY()-(lo))*(t.getY()-(lo))*53*53));
          	       t.setDistance((int) Math.round(distance));  
	        	   traegers.add(t);
	           }
  
	       }
	       catch (Exception n)
	       {
	           n.printStackTrace();

	       }
	       finally
	       {
	           if (conn != null)
	           {
	               try
	               {
	                   conn.close ();
	                   //System.out.println ("Database connection terminated");
	               }
	               catch (Exception n) { /* ignore close errors */ }
	           }
	       }
		return traegers;
	   }   
    
    public List<Traeger> getAllGeoResults(String keyword, int catid, int subid,int la, int lo) 
    {
  	  Connection conn = null;
        List<Traeger> traegers = new ArrayList<Traeger>();
        PreparedStatement pstm = null;
        ResultSet rs = null; 
        System.out.println("keyword:" + keyword);
        System.out.println("catid:" + catid);
        System.out.println("subid:" + subid);
        if((keyword.equals("null")) && (catid != 0) && (subid == 0))
        {
      	  System.out.println("fall1");
      	  try
            {
               String url = "jdbc:mysql://localhost:3306/sozialraum_db_neu";
               Class.forName ("com.mysql.jdbc.Driver");
               conn = DriverManager.getConnection (url,"root","1234");
               pstm = conn.prepareStatement("SELECT  * FROM sozialraum_db_neu.kategorie k, "
               		+ "sozialraum_db_neu.traeger_kat_mapping tkm, "
               		+ "sozialraum_db_neu.traeger t,"
               		+ "sozialraum_db_neu.kat_mapping km "
               		+ "WHERE t.id = tkm.traeger_id "
               		+ "AND k.id = tkm.traeger_kat_id "
               		+ "AND tkm.traeger_id = t.id "
               		+ "AND k.id = ? "
               		+ "AND k.id = km.kat_id "
               		+ "AND km.parent_kat_id = 0 ");
               pstm.setInt(1, catid);
               rs =pstm.executeQuery();
               while(rs.next())
               {
                Traeger t = new Traeger();
          	    t.setId(rs.getInt(5));
          	    t.setName(rs.getString(6));
          	    t.setPlz(rs.getInt(7));
          	    t.setStrasse(rs.getString(8));
          	    t.setHausnummer(rs.getInt(9));
          	    t.setTelefon(rs.getString(10));
          	    t.setFax(rs.getString(11));
          	    t.setAnsprechpartner(rs.getString(12));
          	    t.setEmail(rs.getString(13));
          	    t.setWebsite(rs.getString(14));
                t.setAngebot(rs.getString(15));
                t.setSprachen(rs.getString(16));
                t.setX(rs.getInt(17));
         	    t.setY(rs.getInt(18));
         	    int distance = (int) (Math.sqrt(((t.getX()-(la))*(t.getX()-(la)))*69.1 *69.1)+((t.getY()-(lo))*(t.getY()-(lo))*53*53));
         	    t.setDistance((int) Math.round(distance));  
          	    traegers.add(t);
                }
              }
              catch (Exception n)
              {
                n.printStackTrace();

              }
              finally
              {
                if (conn != null)
                {
                  try
                  {
                     conn.close ();
                     //System.out.println ("Database connection terminated");
                  }
                  catch (Exception n) { /* ignore close errors */ }
                 }
              }
           }
     
        else if((keyword.equals("null")) &&(catid != 0) && (subid != 0))
        {
      	  System.out.println("fall2");
      	  try
            {
               String url = "jdbc:mysql://localhost:3306/sozialraum_db_neu";
               Class.forName ("com.mysql.jdbc.Driver");
               conn = DriverManager.getConnection (url,"root","1234");
               pstm = conn.prepareStatement("SELECT DISTINCT * FROM sozialraum_db_neu.kategorie k, "
               		+ "sozialraum_db_neu.traeger_kat_mapping tkm, "
               		+ "sozialraum_db_neu.traeger t "
               		+ "WHERE k.id = tkm.traeger_kat_id "
               		+ "AND t.id = tkm.traeger_id "
               		+ "AND k.id = ? " );
              // pstm.setInt(1, catid);
               pstm.setInt(1, subid);	
        	     rs =pstm.executeQuery();
               while(rs.next())
               {
                  Traeger t = new Traeger();
          	    t.setId(rs.getInt(5));
          	    t.setName(rs.getString(6));
          	    t.setPlz(rs.getInt(7));
          	    t.setStrasse(rs.getString(8));
          	    t.setHausnummer(rs.getInt(9));
          	    t.setTelefon(rs.getString(10));
          	    t.setFax(rs.getString(11));
          	    t.setAnsprechpartner(rs.getString(12));
          	    t.setEmail(rs.getString(13));
          	    t.setWebsite(rs.getString(14));
                t.setAngebot(rs.getString(15));
                t.setSprachen(rs.getString(16));
                t.setX(rs.getInt(17));
         	    t.setY(rs.getInt(18));
         	    int distance = (int) (Math.sqrt(((t.getX()-(la))*(t.getX()-(la)))*69.1 *69.1)+((t.getY()-(lo))*(t.getY()-(lo))*53*53));
         	    t.setDistance((int) Math.round(distance));  
          	    traegers.add(t);
                }
              }
              catch (Exception n)
              {
                n.printStackTrace();

              }
              finally
              {
                if (conn != null)
                {
                  try
                  {
                     conn.close ();
                     //System.out.println ("Database connection terminated");
                  }
                  catch (Exception n) { /* ignore close errors */ }
                 }
              }  
        }
        else if ((!keyword.equals("null")) && (catid != 0) && (subid !=0))
        {
      	  System.out.println("fall3");
       	 try
            {
               String url = "jdbc:mysql://localhost:3306/sozialraum_db_neu";
               Class.forName ("com.mysql.jdbc.Driver");
               conn = DriverManager.getConnection (url,"root","1234");
               pstm = conn.prepareStatement("SELECT * FROM sozialraum_db_neu.kategorie k, "
               		+ "sozialraum_db_neu.traeger_kat_mapping tkm,  "
               		+ "sozialraum_db_neu.traeger t "
               		+ "WHERE k.id = tkm.traeger_kat_id "
               		+ "AND t.id =tkm.traeger_id "
               		+ "AND k.id = ? "
               		+ "AND( t.plz LIKE ? "
               		+ "OR t.strasse LIKE ? "
               		+ "OR t.hausnummer LIKE ? "
               		+ "OR t.telefon LIKE ? "
               		+ "OR t.fax LIKE ? "
               		+ "OR t.ansprechpartner LIKE ? "
               		+ "OR t.email LIKE ? "
               		+ "OR t.website LIKE ? "
               		+ "OR t.angebot LIKE ? "
               		+ "OR t.sprachen LIKE ?)");
               
               keyword = "%" + keyword+ "%";
              // pstm.setInt(1, catid);
               pstm.setInt(1, subid);
               pstm.setString(2, keyword);
               pstm.setString(3, keyword);	
               pstm.setString(4, keyword);
               pstm.setString(5, keyword);	
               pstm.setString(6, keyword);
               pstm.setString(7, keyword);	
               pstm.setString(8, keyword);
               pstm.setString(9, keyword);
               pstm.setString(10, keyword);
               pstm.setString(11, keyword);
        	    rs =pstm.executeQuery();
               while(rs.next())
               {
                Traeger t = new Traeger();
          	    t.setId(rs.getInt(5));
          	    t.setName(rs.getString(6));
          	    t.setPlz(rs.getInt(7));
          	    t.setStrasse(rs.getString(8));
          	    t.setHausnummer(rs.getInt(9));
          	    t.setTelefon(rs.getString(10));
          	    t.setFax(rs.getString(11));
          	    t.setAnsprechpartner(rs.getString(12));
          	    t.setEmail(rs.getString(13));
          	    t.setWebsite(rs.getString(14));
                t.setAngebot(rs.getString(15));
                t.setSprachen(rs.getString(16));
                t.setX(rs.getInt(17));
         	    t.setY(rs.getInt(18));
         	    int distance = (int) (Math.sqrt(((t.getX()-(la))*(t.getX()-(la)))*69.1 *69.1)+((t.getY()-(lo))*(t.getY()-(lo))*53*53));
         	    t.setDistance((int) Math.round(distance));  
          	    traegers.add(t);
                }
              }
              catch (Exception n)
              {
                n.printStackTrace();

              }
              finally
              {
                if (conn != null)
                {
                  try
                  {
                     conn.close ();
                     //System.out.println ("Database connection terminated");
                  }
                  catch (Exception n) { /* ignore close errors */ }
                 }
              }  
        }
        else if((!keyword.equals("null")) && (catid != 0) && (subid == 0))
        {
      	  System.out.println("fall4");
       	 try
            {
               String url = "jdbc:mysql://localhost:3306/sozialraum_db_neu";
               Class.forName ("com.mysql.jdbc.Driver");
               conn = DriverManager.getConnection (url,"root","1234");
               pstm = conn.prepareStatement("SELECT DISTINCT * FROM sozialraum_db_neu.kategorie k, "
               		+ "sozialraum_db_neu.traeger_kat_mapping tkm,"
               		+ "sozialraum_db_neu.traeger t "
               		+ "WHERE k.id = ? "
               		+ "AND tkm.traeger_kat_id = k.id "
               		+ "AND t.id = tkm.traeger_id "
               		+ "AND ( t.plz LIKE ? "
               		+ "OR t.strasse LIKE ? "
               		+ "OR t.hausnummer LIKE ? "
               		+ "OR t.telefon LIKE ? "
               		+ "OR t.fax LIKE ? "
               		+ "OR t.ansprechpartner LIKE ? "
               		+ "OR t.email LIKE ? "
               		+ "OR t.website LIKE ? "
               		+ "OR t.angebot LIKE ? "
               		+ "OR t.sprachen LIKE ?)");
               keyword = "%" + keyword+ "%";
               pstm.setInt(1, catid);	
               pstm.setString(2, keyword);
               pstm.setString(3, keyword);	
               pstm.setString(4, keyword);
               pstm.setString(5, keyword);	
               pstm.setString(6, keyword);
               pstm.setString(7, keyword);	
               pstm.setString(8, keyword);
               pstm.setString(9, keyword);
               pstm.setString(10, keyword);
               pstm.setString(11, keyword);
        	   rs =pstm.executeQuery();
               while(rs.next())
               {
                Traeger t = new Traeger();
          	    t.setId(rs.getInt(5));
          	    t.setName(rs.getString(6));
          	    t.setPlz(rs.getInt(7));
          	    t.setStrasse(rs.getString(8));
          	    t.setHausnummer(rs.getInt(9));
          	    t.setTelefon(rs.getString(10));
          	    t.setFax(rs.getString(11));
          	    t.setAnsprechpartner(rs.getString(12));
          	    t.setEmail(rs.getString(13));
          	    t.setWebsite(rs.getString(14));
                t.setAngebot(rs.getString(15));
                t.setSprachen(rs.getString(16));
                t.setX(rs.getInt(17));
         	    t.setY(rs.getInt(18));
         	    int distance = (int) (Math.sqrt(((t.getX()-(la))*(t.getX()-(la)))*69.1 *69.1)+((t.getY()-(lo))*(t.getY()-(lo))*53*53));
         	    t.setDistance((int) Math.round(distance));  
          	    traegers.add(t);
                }
              }
              catch (Exception n)
              {
                n.printStackTrace();

              }
              finally
              {
                if (conn != null)
                {
                  try
                  {
                     conn.close ();
                     //System.out.println ("Database connection terminated");
                  }
                  catch (Exception n) { /* ignore close errors */ }
                 }
              }  
        }
        else if((!keyword.equals("null")) && (catid == 0) && (subid == 0))
        {
      	  System.out.println("fall5");
       	 try
            {
               String url = "jdbc:mysql://localhost:3306/sozialraum_db_neu";
               Class.forName ("com.mysql.jdbc.Driver");
               conn = DriverManager.getConnection (url,"root","1234");
               pstm = conn.prepareStatement("SELECT DISTINCT * FROM"
               		+ " sozialraum_db_neu.traeger t "
               		+ "WHERE ( t.plz LIKE ? "
               		+ "OR t.strasse LIKE ? "
               		+ "OR t.hausnummer LIKE ? "
               		+ "OR t.telefon LIKE ? "
               		+ "OR t.fax LIKE ? "
               		+ "OR t.ansprechpartner LIKE ? "
               		+ "OR t.email LIKE ? "
               		+ "OR t.website LIKE ? "
               		+ "OR t.angebot LIKE ? "
               		+ "OR t.sprachen LIKE ?)");
               keyword = "%" + keyword+ "%";
               pstm.setString(1, keyword);
               pstm.setString(2, keyword);	
               pstm.setString(3, keyword);
               pstm.setString(4, keyword);	
               pstm.setString(5, keyword);
               pstm.setString(6, keyword);	
               pstm.setString(7, keyword);
               pstm.setString(8, keyword);
               pstm.setString(9, keyword);
               pstm.setString(10, keyword);
        	    rs =pstm.executeQuery();
               while(rs.next())
               {
                  Traeger t = new Traeger();
          	       t.setId(rs.getInt(1));
          	       t.setName(rs.getString(2));
          	       t.setPlz(rs.getInt(3));
          	       t.setStrasse(rs.getString(4));
          	       t.setHausnummer(rs.getInt(5));
          	       t.setTelefon(rs.getString(6));
          	       t.setFax(rs.getString(7));
          	       t.setAnsprechpartner(rs.getString(8));
          	       t.setEmail(rs.getString(9));
          	       t.setWebsite(rs.getString(10));
          	       t.setAngebot(rs.getString(11));
          	       t.setSprachen(rs.getString(12));
          	       t.setX(rs.getInt(13));
          	       t.setY(rs.getInt(14));
          	       int distance = (int) (Math.sqrt(((t.getX()-(la))*(t.getX()-(la)))*69.1 *69.1)+((t.getY()-(lo))*(t.getY()-(lo))*53*53));
          	       t.setDistance((int) Math.round(distance));  
          	       traegers.add(t);
                }
              }
              catch (Exception n)
              {
                n.printStackTrace();

              }
              finally
              {
                if (conn != null)
                {
                  try
                  {
                     conn.close ();
                     //System.out.println ("Database connection terminated");
                  }
                  catch (Exception n) { /* ignore close errors */ }
                 }
              }  
        }
       else
       {
      	traegers = getAllTraegers(la, lo);  
       }
        
       // Sorting
       Collections.sort(traegers, new Comparator<Traeger>() 
       {
                @Override
                public int compare(Traeger traeger2, Traeger traeger1)
                {

                    return Integer.compare(traeger1.getDistance(), traeger2.getDistance());
                  		 
        }
          });
  	return traegers;
}
}
