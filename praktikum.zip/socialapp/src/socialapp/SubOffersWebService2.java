package socialapp;

import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/suboffersu")
public class SubOffersWebService2 
{
OffersService offerService = new OffersService();
	
	@GET
	@Path("/{param1}")
	@Produces(MediaType.APPLICATION_JSON)
	public String getAllUKategories(@PathParam("param1") int catid) throws JSONException
	{
		List<Unterkategorien> categories = offerService.getselectedUKategories(catid);
		JSONObject jResult = new JSONObject();// main object
        JSONArray jArray = new JSONArray();// /ItemDetail jsonArray
        for(Unterkategorien uk : categories) 
        {
            JSONObject jGroup = new JSONObject();// /sub Object

            try 
            {
                jGroup.put("id", uk.getId());
                jGroup.put("name", uk.getName());
                jArray.put(jGroup);

                // /itemDetail Name is JsonArray Name
                jResult.put("unterkategorie", jArray);
            } 
            catch (JSONException e) 
            {
                e.printStackTrace();
            }
	   }
		return jResult.toString(4);
  }
}
