package socialapp;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Bei dieser Klasse handelt sich um ein Service welche eine Rest-Anfrage bearbeitet 
 * und die Antwort zurueschickt. Bei dieser Anfrage wird eine Liste von allen Traeger als
 * JSON-Objekt zur�ckgeliefert.
 *
 * @author Konstantinos Tsiamis
 * @version M�rz 2017
 */
@Path("/traeger")//Setzt den Pfad der Url um auf diesen Service zuzugreifen.
public class TraegerWebService 
{

	OffersService offerService = new OffersService();
	
	@GET //Request wird geschickt,d.h.es wird etwas zurueckgeschickt
	@Produces(MediaType.APPLICATION_JSON)//Legt fest welcher Typ die repraesentation der ressource, die an den client gesendet wird
	public String getAllTraegers() throws JSONException 
	{	
	    List<Traeger> traegers = offerService.getAllTraegers();
	    JSONObject jResult = new JSONObject();// main object
        JSONArray jArray = new JSONArray();// /ItemDetail jsonArray
        for (Traeger t : traegers) 
        {
            JSONObject jGroup = new JSONObject();// /sub Object

            try 
            {
                jGroup.put("id", t.getId());
                jGroup.put("name", t.getName());
                jGroup.put("ansprechpartner", t.getAnsprechpartner());
                jGroup.put("angebot", t.getAngebot());
                jArray.put(jGroup);

                // /itemDetail Name is JsonArray Name
                jResult.put("traeger", jArray);
            } 
            catch (JSONException e) 
            {
                e.printStackTrace();
            }
	   }
		return jResult.toString(4);
	}
}

