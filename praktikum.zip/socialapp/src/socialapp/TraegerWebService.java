package socialapp;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
@Path("/traeger")

public class TraegerWebService 
{

	OffersService offerService = new OffersService();
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String getAllTraegers() throws JSONException 
	{	
	    List<Traeger> traegers = offerService.getAllTraegers();
	    JSONObject jResult = new JSONObject();// main object
        JSONArray jArray = new JSONArray();// /ItemDetail jsonArray
        for (Traeger t : traegers) 
        {
            JSONObject jGroup = new JSONObject();// /sub Object

            try 
            {
                jGroup.put("id", t.getId());
                jGroup.put("name", t.getName());
                jGroup.put("ansprechpartner", t.getAnsprechpartner());
                jGroup.put("angebot", t.getAngebot());
                jArray.put(jGroup);

                // /itemDetail Name is JsonArray Name
                jResult.put("traeger", jArray);
            } 
            catch (JSONException e) 
            {
                e.printStackTrace();
            }
	   }
		return jResult.toString(4);
	}
}

