package socialapp;

/**
 * Bei dieser Klasse handelt sich um eine Modellklasse f�r das Objekt Traeger.
 *
 * @author Konstantinos Tsiamis
 * @version M�rz 2017
 */
public class Traeger {
	/**
	 * Deklaration der Variablen also, welche Eigenschaften der Traeger besitzt
	 */
	private int Id;
	private String name;
	private int plz;
	private String strasse;
	private int hausnummer;
	private String telefon;
	private String fax;
	private String ansprechpartner;
	private String angebot;
	private String sprachen;
	private String email;
	private String website;
	private int x;
	private int y;
	private int distance;

	// Konstruktor der Klasse
	public Traeger() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Gibt die ID des Traegers
	 */
	public int getId() {
		return Id;
	}

	/**
	 * Setzt die ID des Traegers
	 * 
	 * @param id Die ID des Traegers
	 */
	public void setId(int id) {
		this.Id = id;
	}

	/**
	 * Gibt den Namen des Traegers
	 */
	public String getName() {
		return name;
	}

	/**
	 * Setzt den Namen des Traegers
	 * 
	 * @param name Der Name des Traegers
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Gibt die Postleitzahl des Traegers
	 */
	public int getPlz() {
		return plz;
	}

	/**
	 * Setzt die Postleitzahl des Traegers
	 * 
	 * @param plz Die Postleitzahl des Traegers
	 */
	public void setPlz(int plz) {
		this.plz = plz;
	}

	/**
	 * Gibt die Strasse des Traegers
	 */
	public String getStrasse() {
		return strasse;
	}

	/**
	 * Setzt die Strasse des Traegers
	 * 
	 * @param strasse Die Strasse des Traegers
	 */
	public void setStrasse(String strasse) {
		this.strasse = strasse;
	}

	/**
	 * Gibt die Hausnummer des Traegers
	 */
	public int getHausnummer() {
		return hausnummer;
	}

	/**
	 * Setzt die Hausnummer des Traegers
	 * 
	 * @param hausnummer Hausnummer des Traegers
	 */
	public void setHausnummer(int hausnummer) {
		this.hausnummer = hausnummer;
	}

	/**
	 * Gibt die Telefonnummer des Traegers zur�ck
	 */
	public String getTelefon() {
		return telefon;
	}

	/**
	 * Setzt die Telefonnummer des Traegers
	 * 
	 * @param telefon Telefonnummer des Traegers
	 */
	public void setTelefon(String telefon) {
		this.telefon = telefon;
	}

	/**
	 * Gibt die Faxnummer des Traegers
	 */
	public String getFax() {
		return fax;
	}

	/**
	 * Setzt die Faxnummer des Traegers
	 * 
	 * @param fax Faxnummer des Traegers
	 */
	public void setFax(String fax) {
		this.fax = fax;
	}

	/**
	 * Gibt den Ansprechpartner des Traegers
	 */
	public String getAnsprechpartner() {
		return ansprechpartner;
	}

	/**
	 * Setze den Ansprechspartner des Traegers
	 * 
	 * @param ansprechpartner Ansprechpartner des Traegers
	 */
	public void setAnsprechpartner(String ansprechpartner) {
		this.ansprechpartner = ansprechpartner;
	}

	/**
	 * Gibt das Angebot des Traegers
	 */
	public String getAngebot() {
		return angebot;
	}

	/**
	 * Setze das Angebot des Traegers
	 * 
	 * @param angebot
	 */
	public void setAngebot(String angebot) {
		this.angebot = angebot;
	}

	/**
	 * Gibt die Sprachen des Traegers zur�ck
	 */
	public String getSprachen() {
		return sprachen;
	}

	/**
	 * Setzt die Sprachen des Traegers
	 * 
	 * @param sprachen
	 */
	public void setSprachen(String sprachen) {
		this.sprachen = sprachen;
	}

	/**
	 * Gibt die Email des Traegers
	 */
	public String getEmail() {
		return email;
	}

	/**
	 * Setze die Email des Traeges
	 * 
	 * @param email Email des Traegers
	 */
	public void setEmail(String email) {
		this.email = email;
	}

	/**
	 * Gibt die Website des Traegers
	 */
	public String getWebsite() {
		return website;
	}

	/**
	 * Setze die Website des Traegers
	 * 
	 * @param website
	 */
	public void setWebsite(String website) {
		this.website = website;
	}

	/**
	 * Gibt die X-Koordinate des Traegers
	 */
	public int getX() {
		return x;
	}

	/**
	 * Setze die X-Koordinate des Traegers
	 * 
	 * @param x  X-Koordiante des Traegers
	 */
	public void setX(int x) {
		this.x = x;
	}

	/**
	 * Gibt Y-Koordinate des Traegers
	 */
	public int getY() {
		return y;
	}

	/**
	 * Setze die Y-Koordinate des Traegers
	 * 
	 * @param y Y-Koordiante des Traegers
	 */
	public void setY(int y) {
		this.y = y;
	}

	/**
	 * Gibt die Entfernung des Traegers
	 */
	public int getDistance() {
		return distance;
	}

	/**
	 * Setze die Distanz des Traegers
	 * 
	 * @param distance Distanz des Traegers
	 */
	public void setDistance(int distance) {
		this.distance = distance;
	}
}
