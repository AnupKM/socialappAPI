package socialapp;

public class Traeger 
{
	
	   private int Id;
	   private String name;
	   private int plz;
	   private String strasse;
	   private int hausnummer;
	   private String telefon;
	   private String fax;
	   private String ansprechpartner;
	   private String angebot;
	   private String sprachen;
	   private String email;
	   private String website;
	   private int x;
	   private int y;
	   private int distance;
	   
   public int getX() {
		return x;
	}
	public void setX(int x) {
		this.x = x;
	}
	public int getY() {
		return y;
	}
	public void setY(int y) {
		this.y = y;
	}
	public int getDistance() {
		return distance;
	}
	public void setDistance(int distance) {
		this.distance = distance;
	}
public Traeger() 
   {
	  super();
	  // TODO Auto-generated constructor stub
   }
   public int getId() 
   {
	 return Id;
   }
	public void setId(int id) 
	{
		this.Id = id;
	}
	public String getName() 
	{
		return name;
	}
	public void setName(String name) 
	{
		this.name = name;
	}
	public int getPlz() 
	{
		return plz;
	}
	public void setPlz(int plz) 
	{
		this.plz = plz;
	}
	public String getStrasse() 
	{
		return strasse;
	}
	public void setStrasse(String strasse) 
	{
		this.strasse = strasse;
	}
	public int getHausnummer() 
	{
		return hausnummer;
	}
	public void setHausnummer(int hausnummer) 
	{
		this.hausnummer = hausnummer;
	}
	public String getTelefon() 
	{
		return telefon;
	}
	public void setTelefon(String telefon) 
	{
		this.telefon = telefon;
	}
	public String getFax() 
	{
		return fax;
	}
	public void setFax(String fax) 
	{
		this.fax = fax;
	}
	public String getAnsprechpartner() 
	{
		return ansprechpartner;
	}
	public void setAnsprechpartner(String ansprechpartner) 
	{
		this.ansprechpartner = ansprechpartner;
	}
	public String getAngebot() 
	{
		return angebot;
	}
	public void setAngebot(String angebot) 
	{
		this.angebot = angebot;
	}
	public String getSprachen() 
	{
		return sprachen;
	}
	public void setSprachen(String sprachen)
	{
		this.sprachen = sprachen;
	}
	   public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getWebsite() {
			return website;
		}
		public void setWebsite(String website) {
			this.website = website;
		}
	
	
}
