package socialapp;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

// Plain old Java Object it does not extend as class or implements
// an interface

// The class registers its methods for the HTTP GET request using the @GET annotation.
// Using the @Produces annotation, it defines that it can deliver several MIME types,
// text, XML and HTML.

// The browser requests per default the HTML MIME type.

//Sets the path to base URL + /hello
@Path("/offers")
public class OffersWebService 
{
	
	OffersService offerService = new OffersService();
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public String getAllCategories() throws JSONException  
	{
		List<Kategorie> categories = offerService.getAllKategories();
		JSONObject jResult = new JSONObject();// main object
        JSONArray jArray = new JSONArray();// /ItemDetail jsonArray
        for (Kategorie k : categories) 
        {
            JSONObject jGroup = new JSONObject();// /sub Object

            try 
            {
                jGroup.put("id", k.getId());
                jGroup.put("name", k.getName());
                jArray.put(jGroup);

                // /itemDetail Name is JsonArray Name
                jResult.put("kategorie", jArray);
            } 
            catch (JSONException e) 
            {
                e.printStackTrace();
            }
	   }
		return jResult.toString(4);
	}
	
}
