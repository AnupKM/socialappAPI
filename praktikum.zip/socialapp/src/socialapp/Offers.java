package socialapp;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.application.Application;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.model.SelectItem;

/**
 * Bei dieser Klasse handelt sich um eine Klasse zum Testen der Verbindung einer Webapplikation
 * zu dem Webservice. Sie hat nichts mit der API zu tun. Sie diente lediglich dazu meinen Kollegen Walter
 * zu zeigen, wie man eine Verbindung zwischen API und Webapplikation aussehen k�nnte. Sie zeigt nur ein Textfeld mit dem
 * Input Test und ein Dropdownmenue ohne Inhalt.
 *
 * @author Konstantinos Tsiamis
 * @version M�rz 2017
 */
@ManagedBean(name = "offers", eager = true) //registriert die Klasse offers f�r das JSF framework
@SessionScoped //Verbindung zum Nutzer
@RequestScoped //Antwort auf die Anfrage eines Nutzers
public class Offers implements Serializable{

	private static final long serialVersionUID = -8000208764262863872L;//f�r das JSF framework
	@ManagedProperty(value="#{offersService.allCategories}") //die Verbindug zur Methode herstellen, aufstellen einer dependency injection
	private OffersService offersService;
	List<SelectItem> item;

    //Getter- und Settermethoden 
	public OffersService getOffersService() {
		return offersService;
	}

	public void setOffersService(OffersService offersService) {
		this.offersService = offersService;
	}
    
	//Ausgabe der Webapplikation
	private String name = "TEST";

	//Konstruktor
	public Offers() {
		super();	
	}
	
   
    /*
    public List<Kategorie> getAllCategories() {
		List<Kategorie> categories = offersService.getAllKategories();
		return categories;
	}
	*/
    
  
	
    //Gebe alle Oberkategorien aus
	public List<SelectItem> getCategories()
    {
    	List<SelectItem> items = new ArrayList<SelectItem>();
    	for(Kategorie k : getAllCategories())
    	{
    		SelectItem i = new SelectItem(k.getName(), k.getName());
    		items.add(i);
    	}
    	System.out.print("size:" + getAllCategories().size());
    	return items;
    }
	
	//Getter-Settter Methoden
	//Setze alle Eigenschaften der Oberkategorien 
	public void setCategories(List<SelectItem> item)
    {
    	this.item = item;
    }
     
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
    //FacesContext enth�lt per-request status f�r die Webapplikation
	public List<Kategorie> getAllCategories() {
        FacesContext context = FacesContext.getCurrentInstance();
        Application application = context.getApplication();
        @SuppressWarnings("deprecation")
		ValueBinding binding = application.createValueBinding("#{offersService}");
        @SuppressWarnings("deprecation")
		OffersService offersService = (OffersService)binding.getValue(context);
        return offersService.getAllKategories();
    }
}
