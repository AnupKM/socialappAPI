package socialapp;


import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.faces.application.Application;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.RequestScoped;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import javax.faces.el.ValueBinding;
import javax.faces.model.SelectItem;

@ManagedBean(name = "offers", eager = true)
@SessionScoped
@RequestScoped
public class Offers implements Serializable{

	private static final long serialVersionUID = -8000208764262863872L;
	@ManagedProperty(value="#{offersService.allCategories}")
	private OffersService offersService;
	List<SelectItem> item;


	public OffersService getOffersService() {
		return offersService;
	}

	public void setOffersService(OffersService offersService) {
		this.offersService = offersService;
	}

	private String name = "TEST";

	//Variables
	
	public Offers() {
		super();	
	}
	
	//Getters/Setters
   
    /*
    public List<Kategorie> getAllCategories() {
		List<Kategorie> categories = offersService.getAllKategories();
		return categories;
	}
	*/
    
  
	

	public List<SelectItem> getCategories()
    {
    	List<SelectItem> items = new ArrayList<SelectItem>();
    	for(Kategorie k : getAllCategories())
    	{
    		SelectItem i = new SelectItem(k.getName(), k.getName());
    		items.add(i);
    	}
    	System.out.print("size:" + getAllCategories().size());
    	return items;
    }
	
	public void setCategories(List<SelectItem> item)
    {
    	this.item = item;
    }

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public List<Kategorie> getAllCategories() {
        FacesContext context = FacesContext.getCurrentInstance();
        Application application = context.getApplication();
        @SuppressWarnings("deprecation")
		ValueBinding binding = application.createValueBinding("#{offersService}");
        @SuppressWarnings("deprecation")
		OffersService offersService = (OffersService)binding.getValue(context);
        return offersService.getAllKategories();
    }
	

}
