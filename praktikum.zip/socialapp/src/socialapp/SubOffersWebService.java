package socialapp;

import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 * Bei dieser Klasse handelt sich um ein Service welche eine Rest-Anfrage bearbeitet 
 * und die Antwort zurueschickt. Bei dieser Anfrage wird eine Liste von allen Unterkategorien als
 * JSON-Objekt zur�ckgeliefert.
 *
 * @author Konstantinos Tsiamis
 * @version M�rz 2017
 */

@Path("/suboffers")//Setzt den Pfad der Url um auf diesen Service zuzugreifen.
public class SubOffersWebService 
{

	OffersService offerService = new OffersService();
	
	@GET//Request wird geschickt,d.h.es wird etwas zurueckgeschickt
	@Produces(MediaType.APPLICATION_JSON)//Legt fest welcher Typ die repraesentation der ressource, die an den client gesendet wird
	public String getAllUKategories() throws JSONException
	{
		List<Unterkategorien> categories = offerService.getAllUKategories();
		JSONObject jResult = new JSONObject();// main object
        JSONArray jArray = new JSONArray();// /ItemDetail jsonArray
        for(Unterkategorien uk : categories) 
        {
            JSONObject jGroup = new JSONObject();// /sub Object

            try 
            {
                jGroup.put("id", uk.getId());
                jGroup.put("name", uk.getName());
                jArray.put(jGroup);

                // /itemDetail Name is JsonArray Name
                jResult.put("unterkategorie", jArray);
            } 
            catch (JSONException e) 
            {
                e.printStackTrace();
            }
	   }
		return jResult.toString(4);
	}
}

