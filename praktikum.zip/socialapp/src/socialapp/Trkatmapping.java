package socialapp;

/**
 * Bei dieser Klasse handelt sich um eine Modellklasse f�r das Objekt
 * Trkatmapping. 
 *
 * @author Konstantinos Tsiamis
 * @version M�rz 2017
 */
public class Trkatmapping {
	/**
	 * Deklaration der Variablen also, welche Eigenschaften der Traeger besitzt
	 */
	private int traegerId;
	private int katId;

	// Konstruktor der Klasse
	public Trkatmapping() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Gibt die TraegerID
	 */
	public int getTraegerId() {
		return traegerId;
	}

	/**
	 * Setze die TraegerId
	 * 
	 * @param traegerId TraegerID des Traegers
	 */
	public void setTraegerId(int traegerId) {
		this.traegerId = traegerId;
	}

	/**
	 * Gibt die KategorieID
	 */
	public int getKatId() {
		return katId;
	}

	/**
	 * Setze die KategorieID
	 * 
	 * @param katId KategorieID der Kategorie
	 */
	public void setKatId(int katId) {
		this.katId = katId;
	}

}
