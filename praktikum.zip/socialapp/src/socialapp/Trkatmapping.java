package socialapp;

public class Trkatmapping 
{
  private int traegerId;
  private int katId;

  
  public Trkatmapping() 
  {
	super();
	// TODO Auto-generated constructor stub
  }


  public int getTraegerId() 
  {
	return traegerId;
  }


  public void setTraegerId(int traegerId) 
  {
	this.traegerId = traegerId;
  }


  public int getKatId() 
  {
	return katId;
  }


  public void setKatId(int katId) 
  {
	this.katId = katId;
  }
 
}
