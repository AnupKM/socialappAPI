package socialapp;

/**
 * Bei dieser Klasse handelt sich um eine Modellklasse f�r das Objekt Kategorie.
 *
 * @author Konstantinos Tsiamis
 * @version M�rz 2017
 */
public class Kategorie {
	/**
	 * Deklaration der Variablen also, welche Eigenschaften die Kategorie
	 * besitzt
	 */
	private int Id;
	private String name;

	// Konstruktor der Klasse Kategorie
	public Kategorie() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * Gibt die ID der Kategorie
	 */
	public int getId() {
		return Id;
	}

	/**
	 * Setze die ID der Kategorie
	 * 
	 * @param id   ID der Kategorie
	 */
	public void setId(int id) {
		this.Id = id;
	}

	/**
	 * Gibt den Namen der Kategorie
	 */
	public String getName() {
		return name;
	}

	/**
	 * Setze den Namen der Kategorie
	 * 
	 * @param name Name der Kategorie
	 */
	public void setName(String name) {
		this.name = name;
	}

}
