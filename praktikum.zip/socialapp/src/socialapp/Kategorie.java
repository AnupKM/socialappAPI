package socialapp;

public class Kategorie 
{
   private int Id;
   private String name;
   
   
 
  public Kategorie() 
  {
	super();
	// TODO Auto-generated constructor stub
   }
  public int getId() 
  {
	return Id;
  }
  public void setId(int id) 
  {
	this.Id = id;
  }
  public String getName() 
  {
	return name;
  }
  public void setName(String name) 
  {
	this.name = name;
  }
   
}
