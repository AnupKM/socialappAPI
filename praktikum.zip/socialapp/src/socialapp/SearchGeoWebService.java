package socialapp;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Bei dieser Klasse handelt sich um ein Service welche eine Rest-Anfrage bearbeitet 
 * und die Antwort zurueschickt. Bei dieser Anfrage wird eine Liste von allen Traeger entsprechend
 * der Parametern JSON-Objekt zur�ckgeliefert. Als Parameter f�r die Anfrage wird als erstes der Suchbegriff als String,
 * zweitens Die ID der Oberkategorie als int und dritens die ID der Unterkategorie als int , viertens eine X-Kooridnate als int
 * und fuenftens eine Y-Koordinate als int erwartet. Liste der Traeger wird hier nach den Distanzen sortiert
 * der Traeger, der als erstes aufgelistet ist am nahesten dran zu den Koordinaten die uebergeben wurden.
 *
 * @author Konstantinos Tsiamis
 * @version M�rz 2017
 */
@Path("/geosearch")//Setzt den Pfad der Url um auf diesen Service zuzugreifen.
public class SearchGeoWebService 
{

		GeoOffersService geooffersService = new GeoOffersService();
		
		@GET //Request wird geschickt,d.h.es wird etwas zurueckgeschickt
		@Path("/{param1}/{param2}/{param3}/{param4}/{param5}")//Setzt die Parameter als Url um auf diesen Service zuzugreifen.
		@Produces(MediaType.APPLICATION_JSON)//Legt fest welcher Typ die repraesentation der ressource, die an den client gesendet wird
		public String geosearch(@PathParam("param1") String keyword, @PathParam("param2") int catid, @PathParam("param3") int subid, @PathParam("param4") int x, @PathParam("param5") int y) throws JSONException
		{
			List<Traeger> map = geooffersService.getAllGeoResults(keyword,catid,subid,x,y);
			JSONObject jResult = new JSONObject();// main object
	        JSONArray jArray = new JSONArray();// /ItemDetail jsonArray
	        for (Traeger s : map) 
	        {
	            JSONObject jGroup = new JSONObject();// /sub Object

	            try 
	            {
	                jGroup.put("id", s.getId());
	                jGroup.put("name", s.getName());
	                jGroup.put("ansprechpartner", s.getAnsprechpartner());
	                jGroup.put("angebot", s.getAngebot());
	                jGroup.put("latitude",s.getX());
	                jGroup.put("longitude",s.getY());

	                jArray.put(jGroup);

	                // /itemDetail Name is JsonArray Name
	                jResult.put("traeger", jArray);
	            } 
	            catch (JSONException e) 
	            {
	                e.printStackTrace();
	            }
		   }
			return jResult.toString(4);
		}	
 }
