package socialapp;

public class Unterkategorien 
{
   private int Id;
   private int parentId;
   private String name;
  
public Unterkategorien() 
   {
	super();
	// TODO Auto-generated constructor stub
   }


   public int getId() 
   {
	return Id;
   }


   public void setId(int id) 
   {
	Id = id;
   }


   public int getParentId() 
   {
	return parentId;
   }

   public void setParentId(int parentId) 
   {
	this.parentId = parentId;
   }
   
   public String getName() 
   {
	return name;
   }


   public void setName(String name) 
   {
	this.name = name;
   }
   
}
