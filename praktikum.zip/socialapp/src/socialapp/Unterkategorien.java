package socialapp;

/**
 * Bei dieser Klasse handelt sich um eine Modellklasse f�r das Objekt UnterKategorie.
 *
 * @author Konstantinos Tsiamis
 * @version M�rz 2017
 */
public class Unterkategorien 
{
   //Deklaration der Variablen
   private int Id;
   private int parentId;
   private String name;
  
   //Konstruktor der Klasse
   public Unterkategorien() 
   {
	super();
	// TODO Auto-generated constructor stub
   }

   /**
    * Gibt die Id der Unterkategorie
    */
   public int getId() 
   {
	return Id;
   }

   /**
    * Setze die id der Unterkategorie
    * @param id ID der Unterkategorie
    */
   public void setId(int id) 
   {
	Id = id;
   }

   /**
    * Gibt die Id der zugehoerigen Oberkategorie
    */
   public int getParentId() 
   {
	return parentId;
   }
   
   /**
    * Setze die id zugehoerigen Oberkategorie
    * @param id ID der Oberkategorie
    */    
   public void setParentId(int parentId) 
   {
	this.parentId = parentId;
   }
   
   /**
    * Gibt den Namen der Unterkategorie
    */
   public String getName() 
   {
	return name;
   }

   /**
    * Setze den Namen der Unterkategorie
    * @param name Name der Unterkategorie
    */
   public void setName(String name) 
   {
	this.name = name;
   }
   
}
