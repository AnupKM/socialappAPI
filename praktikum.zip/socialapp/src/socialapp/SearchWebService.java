package socialapp;

import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Path("/search")
public class SearchWebService 
{
	OffersService offerService = new OffersService();
	
	@GET
	@Path("/{param1}/{param2}/{param3}")
	@Produces(MediaType.APPLICATION_JSON)
	public String search(@PathParam("param1") String keyword, @PathParam("param2") int catid, @PathParam("param3") int subid) throws JSONException
	{
		List<Traeger> map = offerService.getAllResults(keyword,catid,subid);
		JSONObject jResult = new JSONObject();// main object
        JSONArray jArray = new JSONArray();// /ItemDetail jsonArray
        for (Traeger s : map) 
        {
            JSONObject jGroup = new JSONObject();// /sub Object

            try 
            {
                jGroup.put("id", s.getId());
                jGroup.put("name", s.getName());
                jGroup.put("ansprechpartner", s.getAnsprechpartner());
                jGroup.put("angebot", s.getAngebot());

                jArray.put(jGroup);

                // /itemDetail Name is JsonArray Name
                jResult.put("traeger", jArray);
            } 
            catch (JSONException e) 
            {
                e.printStackTrace();
            }
	   }
		return jResult.toString(4);
	}	
}
